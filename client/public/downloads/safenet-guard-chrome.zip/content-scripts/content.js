var content=function(){"use strict";var te=Object.defineProperty;var ne=(m,c,h)=>c in m?te(m,c,{enumerable:!0,configurable:!0,writable:!0,value:h}):m[c]=h;var f=(m,c,h)=>ne(m,typeof c!="symbol"?c+"":c,h);var C,K;function m(i){return i}const c=((K=(C=globalThis.browser)==null?void 0:C.runtime)==null?void 0:K.id)==null?globalThis.chrome:globalThis.browser,h="safenet-guard-panel-host",R=440,I=360;function $(){const i=document.createElement("div");return i.id=h,i.setAttribute("style",["all: initial","position: fixed","top: 0","right: 0","width: 0","height: 100vh","z-index: 2147483647","pointer-events: none"].join("; ")),i}function P(i,t){const e=document.createElement("style");e.textContent=`
    :host, * { box-sizing: border-box; }
    .backdrop {
      position: fixed; inset: 0;
      background: oklch(8% 0.008 250 / 0.5);
      opacity: 0; pointer-events: none;
      transition: opacity ${I}ms cubic-bezier(0.16, 1, 0.3, 1);
      backdrop-filter: blur(2px);
    }
    .backdrop.open { opacity: 1; pointer-events: auto; }

    .panel {
      position: fixed;
      top: 16px;
      right: 16px;
      bottom: 16px;
      width: ${R}px;
      max-width: calc(100vw - 32px);
      transform: translateX(calc(100% + 24px));
      transition: transform ${I}ms cubic-bezier(0.16, 1, 0.3, 1);
      background: oklch(8% 0.008 250);
      border-radius: 22px;
      overflow: hidden;
      box-shadow:
        0 24px 70px oklch(0% 0 0 / 0.5),
        0 0 0 1px oklch(22% 0.014 250),
        inset 0 1px 0 oklch(100% 0 0 / 0.04);
      pointer-events: auto;
      display: flex; flex-direction: column;
    }
    .panel.open { transform: translateX(0); }

    .grip {
      position: absolute;
      top: 14px; left: 14px;
      width: 28px; height: 28px;
      border-radius: 8px;
      background: oklch(13% 0.012 250);
      border: 1px solid oklch(22% 0.014 250);
      color: oklch(62% 0.012 250);
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      font-family: ui-monospace, SF Mono, monospace;
      font-size: 14px; font-weight: 700;
      z-index: 10;
      transition: background 0.2s, color 0.2s, transform 0.2s;
    }
    .grip:hover { background: oklch(16% 0.014 250); color: oklch(98% 0 0); transform: scale(1.04); }

    iframe {
      flex: 1; width: 100%; height: 100%;
      border: 0; background: transparent;
      display: block;
    }

    /* aurora glow on panel edge */
    .panel::before {
      content: '';
      position: absolute;
      inset: -1px;
      border-radius: inherit;
      background: linear-gradient(135deg,
        oklch(78% 0.17 205 / 0.18) 0%,
        transparent 30%,
        transparent 70%,
        oklch(65% 0.22 285 / 0.12) 100%);
      pointer-events: none;
      mix-blend-mode: screen;
    }
  `;const n=document.createElement("div");n.className="backdrop";const o=document.createElement("div");o.className="panel";const r=document.createElement("button");r.className="grip",r.setAttribute("aria-label","Закрыть SafeNet Guard"),r.textContent="✕";const s=document.createElement("iframe");return s.src=t,s.setAttribute("title","SafeNet Guard"),s.setAttribute("allow","clipboard-write"),o.appendChild(r),o.appendChild(s),i.appendChild(e),i.appendChild(n),i.appendChild(o),r.addEventListener("click",()=>{o.classList.remove("open"),n.classList.remove("open")}),n.addEventListener("click",()=>{o.classList.remove("open"),n.classList.remove("open")}),{panel:o,backdrop:n,iframe:s}}function D(){let i=null,t=null,e=null,n=null,o=!1;function r(){if(i)return;i=$(),document.documentElement.appendChild(i),t=i.attachShadow({mode:"open"});const u=P(t,c.runtime.getURL("/sidebar.html"));e=u.panel,n=u.backdrop}function s(){r(),requestAnimationFrame(()=>{e==null||e.classList.add("open"),n==null||n.classList.add("open"),o=!0})}function l(){e==null||e.classList.remove("open"),n==null||n.classList.remove("open"),o=!1}function g(){o?l():s()}return{show:s,hide:l,toggle:g,isOpen:()=>o}}const F=["sber","tinkoff","vtb","alfa","gosuslugi","nalog"],M="safenet_guard_dismissed";function O(){try{return sessionStorage.getItem(M)==="1"}catch{return!1}}function U(){try{sessionStorage.setItem(M,"1")}catch{}}function k(i){return i.replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]??t)}function N(){c.runtime.sendMessage({type:"TRUST_SITE",host:window.location.hostname}).catch(()=>{})}function q(){var z;const i=window.location.origin,e=window.location.protocol==="http:"&&document.querySelectorAll('input[type="password"]').length>0,n=Array.from(document.querySelectorAll("form")).some(p=>{const d=p.action;if(!d)return!1;try{return new URL(d).origin!==i}catch{return!1}}),o=[];document.querySelectorAll("img").forEach(p=>{const d=(p.src??"").toLowerCase(),ee=(p.alt??"").toLowerCase();F.forEach(E=>{(d.includes(E)||ee.includes(E))&&!i.includes(E)&&o.push(E)})});const s=Array.from(document.querySelectorAll("script")).some(p=>{const d=p.textContent??"";return(d.match(/eval\s*\(/g)??[]).length>2||d.includes("atob(")&&d.length>500}),l=Array.from(document.querySelectorAll("a, button")).some(p=>{const d=window.getComputedStyle(p);return d.opacity==="0"&&d.position==="absolute"}),g=/seed[\s-]?phrase|recovery phrase|мнемоническ|сид[\s-]?фраз|приватн\w* ключ|private key|secret recovery/i,u=(((z=document.body)==null?void 0:z.innerText)??"").slice(0,2e4),w=g.test(u),a=document.querySelectorAll("input").length>=12&&/wallet|crypto|metamask|trust ?wallet|phantom|ledger|кошел/i.test(u),S=w||a;return{hasPasswordOnHttp:e,hasExternalFormAction:n,suspiciousBrandLogos:[...new Set(o)],hasObfuscatedJs:s,hasClickjacking:l,hasCryptoDrainer:S}}function T(i,t){var r,s;const e=i.level==="danger",n=document.createElement("div");n.id="safenet-guard-banner",n.setAttribute("style",["position: fixed","top: 0","left: 0","right: 0","z-index: 2147483647",`background: linear-gradient(135deg, ${e?"#7f1d1d, #991b1b":"#78350f, #92400e"})`,`color: ${e?"#fee2e2":"#fef3c7"}`,'font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',"font-size: 14px","padding: 12px 16px","box-shadow: 0 4px 24px rgba(0,0,0,0.4)","display: flex","align-items: flex-start","gap: 12px","animation: safenet-slide-down 0.3s ease"].join("; "));const o=i.signals.slice(0,2).map(l=>`<div style="font-size:12px;opacity:0.85;margin-top:3px">⚠ ${k(l.message)}</div>`).join("");return n.innerHTML=`
    <style>
      @keyframes safenet-slide-down {
        from { transform: translateY(-100%); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
      }
    </style>
    <div style="flex:1">
      <div style="font-weight:700;font-size:15px">${e?"🔴":"🟡"} SafeNet Guard — ${e?"Опасный сайт":"Подозрительный сайт"}</div>
      ${o}
    </div>
    <button id="safenet-trust-btn" style="
      background:transparent;border:1px solid rgba(255,255,255,0.25);color:inherit;
      padding:6px 14px;border-radius:6px;cursor:pointer;font-size:13px;
      flex-shrink:0;margin-top:2px;opacity:0.8
    ">Доверять сайту</button>
    <button id="safenet-close-btn" style="
      background:rgba(255,255,255,0.15);border:none;color:inherit;
      padding:6px 14px;border-radius:6px;cursor:pointer;font-size:13px;font-weight:600;
      flex-shrink:0;margin-top:2px
    ">✕ Закрыть</button>
  `,document.body.prepend(n),(r=n.querySelector("#safenet-trust-btn"))==null||r.addEventListener("click",()=>{N(),n.remove(),t()}),(s=n.querySelector("#safenet-close-btn"))==null||s.addEventListener("click",()=>{n.remove(),t()}),n}function H(i,t){var o,r,s;const e=document.createElement("div");e.id="safenet-guard-overlay",e.setAttribute("style",["position: fixed","inset: 0","z-index: 2147483647","background: rgba(15, 5, 5, 0.97)","color: #fef2f2",'font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',"display: flex","align-items: center","justify-content: center","animation: safenet-fade-in 0.25s ease"].join("; "));const n=i.signals.slice(0,5).map(l=>`
    <div style="
      display:flex;gap:10px;align-items:flex-start;
      background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);
      border-radius:8px;padding:10px 14px;margin-bottom:8px
    ">
      <span style="color:#f87171;font-size:16px;flex-shrink:0">${l.severity==="high"?"🔴":"🟡"}</span>
      <span style="font-size:14px;line-height:1.4">${k(l.message)}</span>
    </div>
  `).join("");return e.innerHTML=`
    <style>
      @keyframes safenet-fade-in { from { opacity: 0; } to { opacity: 1; } }
    </style>
    <div style="max-width:560px;width:90%;padding:32px">
      <div style="text-align:center;margin-bottom:28px">
        <div style="font-size:56px;margin-bottom:12px">🔴</div>
        <div style="font-size:26px;font-weight:800;color:#fca5a5;margin-bottom:8px">Опасный сайт!</div>
        <div style="font-size:15px;opacity:0.7;word-break:break-all">
          ${k(i.url.slice(0,80))}${i.url.length>80?"…":""}
        </div>
        <div style="
          display:inline-block;margin-top:12px;
          background:rgba(239,68,68,0.2);border:1px solid rgba(239,68,68,0.5);
          border-radius:20px;padding:4px 16px;font-size:13px;font-weight:600;color:#fca5a5
        ">Оценка риска: ${i.score}/100</div>
      </div>

      <div style="margin-bottom:24px">
        <div style="font-size:13px;font-weight:600;opacity:0.5;margin-bottom:10px;text-transform:uppercase;letter-spacing:0.5px">
          Обнаруженные угрозы
        </div>
        ${n}
      </div>

      <div style="display:flex;gap:12px">
        <button id="safenet-leave-btn" style="
          flex:1;background:#dc2626;border:none;color:white;
          padding:14px;border-radius:10px;cursor:pointer;font-size:15px;font-weight:700;
        ">← Уйти со страницы</button>
        <button id="safenet-stay-btn" style="
          background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.15);
          color:rgba(255,255,255,0.5);padding:14px 20px;border-radius:10px;
          cursor:pointer;font-size:14px;
        ">Всё равно войти</button>
      </div>

      <div style="text-align:center;margin-top:14px">
        <button id="safenet-trust-btn" style="
          background:none;border:none;cursor:pointer;font-size:12px;
          color:rgba(255,255,255,0.35);text-decoration:underline;padding:4px;
        ">Это ложное срабатывание — доверять этому сайту</button>
      </div>

      <div style="text-align:center;margin-top:8px;font-size:12px;opacity:0.35">
        SafeNet Guard • Анализ выполнен локально
      </div>
    </div>
  `,document.body.appendChild(e),(o=e.querySelector("#safenet-leave-btn"))==null||o.addEventListener("click",()=>{window.history.back(),setTimeout(()=>window.close(),300)}),(r=e.querySelector("#safenet-stay-btn"))==null||r.addEventListener("click",()=>{U(),e.remove(),t()}),(s=e.querySelector("#safenet-trust-btn"))==null||s.addEventListener("click",()=>{N(),e.remove(),t()}),e}const j=1500,G=8;function B(){let i=null,t=null;function e(){i==null||i.remove(),t==null||t.remove(),i=null,t=null}let n="",o="",r=0,s;function l(){const a=q(),S=JSON.stringify(a);S!==n&&(n=S,c.runtime.sendMessage({type:"DOM_FEATURES",features:a}).catch(()=>{}))}const g=new MutationObserver(()=>{if(r>=G){g.disconnect();return}clearTimeout(s),s=setTimeout(()=>{r++,l()},j)});function u(a){if(a.url!==o&&(o=a.url,n="",r=0),e(),a.level==="suspicious")i=T(a,()=>{i=null});else if(a.level==="danger"){if(O()){i=T(a,()=>{i=null});return}t=H(a,()=>{t=null,i=T(a,()=>{i=null})})}}c.runtime.sendMessage({type:"GET_CURRENT_RESULT"}).then(a=>{(a==null?void 0:a.type)==="CURRENT_RESULT"&&a.result&&u(a.result)}).catch(()=>{});const w=D();c.runtime.onMessage.addListener(a=>{a.type==="ANALYSIS_RESULT"&&u(a.result),a.type==="TOGGLE_PANEL"&&w.toggle(),a.type==="CLOSE_PANEL"&&w.hide()}),window.addEventListener("load",l),g.observe(document.documentElement,{childList:!0,subtree:!0})}const Y={matches:["<all_urls>"],runAt:"document_idle",main(){B()}};function y(i,...t){}const V={debug:(...i)=>y(console.debug,...i),log:(...i)=>y(console.log,...i),warn:(...i)=>y(console.warn,...i),error:(...i)=>y(console.error,...i)},v=class v extends Event{constructor(t,e){super(v.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=e}};f(v,"EVENT_NAME",A("wxt:locationchange"));let _=v;function A(i){var t;return`${(t=c==null?void 0:c.runtime)==null?void 0:t.id}:content:${i}`}function W(i){let t,e;return{run(){t==null&&(e=new URL(location.href),t=i.setInterval(()=>{let n=new URL(location.href);n.href!==e.href&&(window.dispatchEvent(new _(n,e)),e=n)},1e3))}}}const b=class b{constructor(t,e){f(this,"isTopFrame",window.self===window.top);f(this,"abortController");f(this,"locationWatcher",W(this));f(this,"receivedMessageIds",new Set);this.contentScriptName=t,this.options=e,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){return c.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,e){const n=setInterval(()=>{this.isValid&&t()},e);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(t,e){const n=setTimeout(()=>{this.isValid&&t()},e);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(t){const e=requestAnimationFrame((...n)=>{this.isValid&&t(...n)});return this.onInvalidated(()=>cancelAnimationFrame(e)),e}requestIdleCallback(t,e){const n=requestIdleCallback((...o)=>{this.signal.aborted||t(...o)},e);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(t,e,n,o){var r;e==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(r=t.addEventListener)==null||r.call(t,e.startsWith("wxt:")?A(e):e,n,{...o,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),V.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:b.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(t){var r,s,l;const e=((r=t.data)==null?void 0:r.type)===b.SCRIPT_STARTED_MESSAGE_TYPE,n=((s=t.data)==null?void 0:s.contentScriptName)===this.contentScriptName,o=!this.receivedMessageIds.has((l=t.data)==null?void 0:l.messageId);return e&&n&&o}listenForNewerScripts(t){let e=!0;const n=o=>{if(this.verifyScriptStartedEvent(o)){this.receivedMessageIds.add(o.data.messageId);const r=e;if(e=!1,r&&(t!=null&&t.ignoreFirstEvent))return;this.notifyInvalidated()}};addEventListener("message",n),this.onInvalidated(()=>removeEventListener("message",n))}};f(b,"SCRIPT_STARTED_MESSAGE_TYPE",A("wxt:content-script-started"));let L=b;const J=Symbol("null");let X=0;class Q extends Map{constructor(...t){super(),this._objectHashes=new WeakMap,this._symbolHashes=new Map,this._publicKeys=new Map;const[e]=t;if(e!=null){if(typeof e[Symbol.iterator]!="function")throw new TypeError(typeof e+" is not iterable (cannot read property Symbol(Symbol.iterator))");for(const[n,o]of e)this.set(n,o)}}_getPublicKeys(t,e=!1){if(!Array.isArray(t))throw new TypeError("The keys parameter must be an array");const n=this._getPrivateKey(t,e);let o;return n&&this._publicKeys.has(n)?o=this._publicKeys.get(n):e&&(o=[...t],this._publicKeys.set(n,o)),{privateKey:n,publicKey:o}}_getPrivateKey(t,e=!1){const n=[];for(const o of t){const r=o===null?J:o;let s;if(typeof r=="object"||typeof r=="function"?s="_objectHashes":typeof r=="symbol"?s="_symbolHashes":s=!1,!s)n.push(r);else if(this[s].has(r))n.push(this[s].get(r));else if(e){const l=`@@mkm-ref-${X++}@@`;this[s].set(r,l),n.push(l)}else return!1}return JSON.stringify(n)}set(t,e){const{publicKey:n}=this._getPublicKeys(t,!0);return super.set(n,e)}get(t){const{publicKey:e}=this._getPublicKeys(t);return super.get(e)}has(t){const{publicKey:e}=this._getPublicKeys(t);return super.has(e)}delete(t){const{publicKey:e,privateKey:n}=this._getPublicKeys(t);return!!(e&&super.delete(e)&&this._publicKeys.delete(n))}clear(){super.clear(),this._symbolHashes.clear(),this._publicKeys.clear()}get[Symbol.toStringTag](){return"ManyKeysMap"}get size(){return super.size}}new Q;function ie(){}function x(i,...t){}const Z={debug:(...i)=>x(console.debug,...i),log:(...i)=>x(console.log,...i),warn:(...i)=>x(console.warn,...i),error:(...i)=>x(console.error,...i)};return(async()=>{try{const{main:i,...t}=Y,e=new L("content",t);return await i(e)}catch(i){throw Z.error('The content script "content" crashed on startup!',i),i}})()}();
content;
