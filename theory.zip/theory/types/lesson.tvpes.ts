/**
 * SafeNet - Типы данных для уроков и заданий
 * Этот файл определяет структуру всех данных в приложении
 */

// ============================================
// БАЗОВЫЕ ТИПЫ
// ============================================

export type DifficultyLevel = 'beginner' | 'intermediate' | 'advanced'

export type CategoryId =
	| 'basics' // Основы безопасности
	| 'phishing' // Фишинг
	| 'websites' // Опасные ссылки и сайты
	| 'passwords' // Пароли
	| 'social-networks' // Соцсети
	| 'shopping' // Покупки
	| 'social-engineering' // Социальная инженерия
	| 'final-mission' // Итоговая миссия

export type TaskType =
	| 'email-analysis' // Анализ email
	| 'url-analysis' // Проверка URL
	| 'multiple-choice' // Множественный выбор
	| 'single-choice' // Один правильный ответ
	| 'password-strength' // Проверка пароля
	| 'website-inspection' // Осмотр сайта
	| 'scenario' // Сценарий с выбором действий
	| 'drag-and-drop' // Перетаскивание элементов
	| 'true-false' // Правда/ложь

// ============================================
// ИНТЕРФЕЙСЫ ДЛЯ ТЕОРИИ
// ============================================

export interface Theory {
	/** Введение в тему */
	introduction: string

	/** Ключевые моменты (массив строк) */
	keyPoints: string[]

	/** Признаки опасности */
	warningSigns?: string[]

	/** Примеры (хорошие и плохие) */
	examples?: {
		good?: string[]
		bad?: string[]
		legitimate?: string | string[]
		phishing?: string | string[]
		suspicious?: string[]
	}

	/** Советы и рекомендации */
	tips?: string[]

	/** Частые ошибки */
	commonMistakes?: string[]
}

// ============================================
// ИНТЕРФЕЙСЫ ДЛЯ ЗАДАНИЙ
// ============================================

export interface BaseTask {
	/** Уникальный ID задания */
	id: number

	/** Тип задания */
	type: TaskType

	/** Текст вопроса */
	question: string

	/** Правильный ответ (один или несколько) */
	correctAnswer: string | string[]

	/** Объяснение правильного ответа */
	explanation: string

	/** Подсказки (опционально) */
	hints?: string[]

	/** Количество баллов за задание */
	points: number
}

export interface Option {
	/** ID варианта ответа (A, B, C, D...) */
	id: string

	/** Текст варианта */
	text: string

	/** Правильный ли ответ */
	isCorrect: boolean

	/** Дополнительное объяснение (опционально) */
	explanation?: string
}

export interface EmailAnalysisTask extends BaseTask {
	type: 'email-analysis'

	/** Данные письма */
	email: {
		from: string
		subject: string
		body: string
		attachments?: string[]
	}

	/** Варианты ответов */
	options: Option[]
}

export interface UrlAnalysisTask extends BaseTask {
	type: 'url-analysis'

	/** Список URL для анализа */
	urls: {
		id: string
		url: string
		isCorrect: boolean
	}[]
}

export interface MultipleChoiceTask extends BaseTask {
	type: 'multiple-choice'

	/** Варианты ответов (можно выбрать несколько) */
	options: Option[]

	/** Массив правильных ответов */
	correctAnswers: string[]
}

export interface SingleChoiceTask extends BaseTask {
	type: 'single-choice'

	/** Варианты ответов (только один правильный) */
	options: Option[]
}

export interface PasswordStrengthTask extends BaseTask {
	type: 'password-strength'

	/** Пароли для оценки */
	passwords: {
		id: string
		password: string
		strength: 'weak' | 'medium' | 'strong'
		issues?: string[]
	}[]
}

export interface ScenarioTask extends BaseTask {
	type: 'scenario'

	/** Описание ситуации */
	scenario: string

	/** Возможные действия */
	actions: Option[]
}

export interface WebsiteInspectionTask extends BaseTask {
	type: 'website-inspection'

	/** Данные сайта */
	website: {
		url: string
		screenshot?: string
		description: string
		suspiciousElements: string[]
	}

	/** Вопросы о сайте */
	options: Option[]
}

export interface TrueFalseTask extends BaseTask {
	type: 'true-false'

	/** Утверждение */
	statement: string

	/** Правильный ответ */
	correctAnswer: 'true' | 'false'
}

// Объединённый тип для всех заданий
export type Task =
	| EmailAnalysisTask
	| UrlAnalysisTask
	| MultipleChoiceTask
	| SingleChoiceTask
	| PasswordStrengthTask
	| ScenarioTask
	| WebsiteInspectionTask
	| TrueFalseTask

// ============================================
// ИНТЕРФЕЙС ДЛЯ ТЕСТИРОВАНИЯ
// ============================================

export interface QuizQuestion {
	/** ID вопроса */
	id: number

	/** Текст вопроса */
	question: string

	/** Варианты ответов */
	options: string[]

	/** Индекс правильного ответа (0-based) */
	correctAnswer: number

	/** Баллы за вопрос */
	points: number

	/** Объяснение (опционально) */
	explanation?: string
}

export interface Quiz {
	/** Минимальный процент для прохождения */
	passingScore: number

	/** Вопросы теста */
	questions: QuizQuestion[]
}

// ============================================
// ИНТЕРФЕЙС РЕСУРСОВ
// ============================================

export interface Resource {
	/** Название ресурса */
	title: string

	/** Ссылка */
	url: string

	/** Тип ресурса */
	type: 'article' | 'video' | 'interactive' | 'pdf' | 'external'

	/** Описание (опционально) */
	description?: string
}

// ============================================
// ГЛАВНЫЙ ИНТЕРФЕЙС УРОКА
// ============================================

export interface Lesson {
	/** Уникальный ID урока */
	id: number

	/** Название урока */
	title: string

	/** Категория */
	category: CategoryId

	/** Уровень сложности */
	difficulty: DifficultyLevel

	/** Базовые баллы за урок */
	points: number

	/** Примерное время прохождения */
	estimatedTime: string

	/** Краткое описание */
	description: string

	/** Иконка (emoji) */
	icon?: string

	/** Теоретический материал */
	theory: Theory

	/** Практические задания */
	tasks: Task[]

	/** Итоговый тест */
	quiz: Quiz

	/** Дополнительные ресурсы */
	resources?: Resource[]

	/** Требуемые уроки (ID уроков, которые нужно пройти сначала) */
	prerequisites?: number[]
}

// ============================================
// ИНТЕРФЕЙС КАТЕГОРИИ
// ============================================

export interface Category {
	/** ID категории */
	id: CategoryId

	/** Название категории */
	name: string

	/** Иконка (emoji) */
	icon: string

	/** Описание */
	description: string

	/** Количество заданий */
	taskCount: number

	/** Цвет темы (hex) */
	color?: string
}

// ============================================
// СИСТЕМА ДОСТИЖЕНИЙ
// ============================================

export interface Achievement {
	/** ID достижения */
	id: string

	/** Название */
	name: string

	/** Описание */
	description: string

	/** Иконка (emoji) */
	icon: string

	/** Баллы за достижение */
	points: number

	/** Условие получения */
	condition: {
		type:
			| 'complete-lesson'
			| 'complete-category'
			| 'streak'
			| 'score'
			| 'perfect-score'
		value?: number | string
	}
}

// ============================================
// ГЛАВНАЯ СТРУКТУРА ДАННЫХ
// ============================================

export interface LessonsData {
	/** Массив всех уроков */
	lessons: Lesson[]

	/** Категории */
	categories: Category[]

	/** Система достижений */
	achievements: Achievement[]

	/** Метаданные */
	metadata: {
		version: string
		lastUpdated: string
		totalLessons: number
		totalTasks: number
	}
}
